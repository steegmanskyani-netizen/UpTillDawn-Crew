export { default } from "../page"
