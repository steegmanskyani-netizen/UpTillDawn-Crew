// ============================================================
// Next.js Middleware — Session refresh + route protection
// Must be at the root as middleware.ts (not inside /app)
// ============================================================

import { type NextRequest } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'

export async function middleware(request: NextRequest) {
    return await updateSession(request)
}

export const config = {
    matcher: [
        /*
         * Match all paths EXCEPT:
         *  - _next/static (static files)
         *  - _next/image (image optimization)
         *  - favicon.ico (favicon)
         *  - public assets
         */
        '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
    ],
}
